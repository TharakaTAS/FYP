# MC04: Wrist Exoskeleton project website

Static site for the MC 4206 FYP (sEMG-driven wrist exoskeleton for stroke
rehabilitation, Team MC 04). Plain HTML/CSS/JS, no framework, no build
step, no dependencies beyond one Google Fonts stylesheet.

## Status

The **home page** (`index.html`), the **About page** (`about.html`), and the
**Signal Processing page** (`signal-processing.html`) are fully built:

- Home: navigation, hero, photo carousel, quick links to each design
  section, team cards, footer.
- About: key-terms glossary, "Why This Matters", Aim, tiered Objectives,
  Outputs, closing CTA.
- Signal Processing: a page-specific sticky sub-nav with scroll-spy, a
  5-step "Big Picture" flow diagram, plain-language sections on acquiring
  the signal, why preprocessing matters, and what MATLAB and the Signal
  Processing Toolbox are (each with a `Show the technical detail` expander
  for deeper, parameter-level content), a 6-step preprocessing pipeline
  walkthrough, and placeholder slots for your own Simulink model
  screenshots and result plots.

The remaining nav pages (`mechanical-design.html`, `control-design.html`,
`ml-design.html`, `future-work.html`, `faq.html`) are working placeholder
pages: real nav, real header/footer, a short paragraph of real content, and
a `[PLACEHOLDER: ...]` marker for what's still to be written. Ask for any
of these to be filled in next.

## File structure

```
index.html                    ← home page (done)
about.html                    ← done
signal-processing.html        ← done (pending your own Simulink/result photos and technical parameters)
mechanical-design.html        ← placeholder
control-design.html           ← placeholder
ml-design.html                ← placeholder
future-work.html              ← placeholder
faq.html                      ← placeholder
css/style.css                 ← all styling (one file, organised by section)
js/script.js                  ← mobile nav toggle, carousel, and page sub-nav
                                 scroll-spy behaviour
assets/img/carousel/          ← drop project photos here (see its README)
assets/img/team/               ← drop team headshots here (see its README)
assets/img/signal-processing/  ← drop Simulink/result photos here (see its README)
assets/img/stock/              ← credited stock photos used on the About and
                                 Signal Processing pages; see its README for
                                 sourcing/licensing
scripts/build_stubs.py        ← helper used to generate the placeholder
                                 pages from a shared header/footer template.
                                 Not part of the live site; safe to ignore
                                 or delete; re-run it if you want to
                                 regenerate a stub page from scratch.
```

## Things still marked `[PLACEHOLDER: ...]`

- LinkedIn / GitHub links in the footer's Connect column: `index.html`
  and every stub page's footer (email and phone are already filled in)
- Team roles/bios for A. G. T. Ariyarathna and W. A. S. S. Weerakkody on
  the home page (roles were split to match the Mechanical / ML nav
  sections as a guess, confirm which teammate is which)
- Home page carousel photos and the two teammates' headshots (see the
  `README.md` files under `assets/img/`)
- Signal Processing page: your own Simulink model screenshots and result
  plots (`assets/img/signal-processing/`), plus the technical parameters
  inside each `Show the technical detail` expander (electrode placement,
  filter cutoffs, sampling rate, specific MATLAB functions used, etc.)
- Full page content for Mechanical Design, Control Design, ML Design,
  Future Work, and FAQ

Search the codebase for `PLACEHOLDER` to find every spot at once:

```bash
grep -rn "PLACEHOLDER" --include="*.html" .
```

## Running it locally

No build step, just open `index.html` in a browser, or serve the folder
so relative paths behave exactly like they will in production:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deploying to GitHub Pages

1. Push this folder to a GitHub repository (the root of the repo, or a
   `/docs` folder, either works).
2. In the repo: **Settings &rarr; Pages &rarr; Build and deployment
   &rarr; Source** = "Deploy from a branch", pick the branch and folder
   you pushed to.
3. GitHub gives you a URL like `https://<username>.github.io/<repo>/`
   within a minute or two.

Because everything is relative paths and there's no build tool, what you
see locally is exactly what will render on Pages.
