/* =========================================================================
   MC04 Wrist Exoskeleton: Site Behaviour
   Plain JS, no dependencies. Two jobs: mobile nav toggle, and the
   home-page photo carousel. Both are defensive; they no-op on pages
   that don't have the relevant markup.
   ========================================================================= */

document.addEventListener('DOMContentLoaded', function () {
  setFooterYear();
  initMobileNav();
  initCarousel();
  initPageNav();
});

/* ---------- Footer year ---------- */
function setFooterYear() {
  var el = document.getElementById('year');
  if (el) el.textContent = new Date().getFullYear();
}

/* ---------- Mobile nav toggle ---------- */
function initMobileNav() {
  var toggle = document.getElementById('navToggle');
  var nav = document.getElementById('siteNav');
  if (!toggle || !nav) return;

  toggle.addEventListener('click', function () {
    var isOpen = nav.classList.toggle('is-open');
    toggle.setAttribute('aria-expanded', String(isOpen));
  });

  // Close the menu when a link is tapped (mobile UX)
  nav.querySelectorAll('a').forEach(function (link) {
    link.addEventListener('click', function () {
      nav.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
    });
  });
}

/* ---------- Page-specific sub-nav (scroll-spy) ---------- */
function initPageNav() {
  var nav = document.getElementById('pageNav');
  if (!nav) return;

  var links = Array.prototype.slice.call(nav.querySelectorAll('.page-nav-link'));
  var sections = links.map(function (link) {
    return document.getElementById(link.getAttribute('href').slice(1));
  }).filter(Boolean);
  if (!sections.length) return;

  function setActive(id) {
    links.forEach(function (link) {
      link.classList.toggle('is-active', link.getAttribute('href') === '#' + id);
    });
  }

  if ('IntersectionObserver' in window) {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) setActive(entry.target.id);
      });
    }, { rootMargin: '-40% 0px -55% 0px', threshold: 0 });
    sections.forEach(function (s) { observer.observe(s); });
  } else {
    setActive(sections[0].id);
  }
}

/* ---------- Carousel ---------- */
function initCarousel() {
  var root = document.getElementById('projectCarousel');
  if (!root) return;

  var track = document.getElementById('carouselTrack');
  var slides = Array.prototype.slice.call(track.children);
  var prevBtn = document.getElementById('carouselPrev');
  var nextBtn = document.getElementById('carouselNext');
  var dotsWrap = document.getElementById('carouselDots');
  var current = 0;
  var AUTOPLAY_MS = 5500;
  var timer = null;

  if (slides.length === 0) return;

  // Build dot indicators
  slides.forEach(function (slide, i) {
    var dot = document.createElement('button');
    dot.type = 'button';
    dot.setAttribute('role', 'tab');
    dot.setAttribute('aria-label', 'Go to slide ' + (i + 1));
    if (i === 0) dot.classList.add('is-active');
    dot.addEventListener('click', function () { goTo(i); restartAutoplay(); });
    dotsWrap.appendChild(dot);
  });
  var dots = Array.prototype.slice.call(dotsWrap.children);

  function render() {
    track.style.transform = 'translateX(-' + (current * 100) + '%)';
    slides.forEach(function (s, i) { s.classList.toggle('is-active', i === current); });
    dots.forEach(function (d, i) { d.classList.toggle('is-active', i === current); });
  }

  function goTo(index) {
    current = (index + slides.length) % slides.length;
    render();
  }

  function next() { goTo(current + 1); }
  function prev() { goTo(current - 1); }

  function startAutoplay() {
    timer = window.setInterval(next, AUTOPLAY_MS);
  }
  function stopAutoplay() {
    if (timer) { window.clearInterval(timer); timer = null; }
  }
  function restartAutoplay() {
    stopAutoplay();
    startAutoplay();
  }

  if (nextBtn) nextBtn.addEventListener('click', function () { next(); restartAutoplay(); });
  if (prevBtn) prevBtn.addEventListener('click', function () { prev(); restartAutoplay(); });

  // Pause on hover / focus, resume on leave
  root.addEventListener('mouseenter', stopAutoplay);
  root.addEventListener('mouseleave', startAutoplay);
  root.addEventListener('focusin', stopAutoplay);
  root.addEventListener('focusout', startAutoplay);

  // Basic touch swipe support
  var touchStartX = null;
  track.addEventListener('touchstart', function (e) { touchStartX = e.touches[0].clientX; }, { passive: true });
  track.addEventListener('touchend', function (e) {
    if (touchStartX === null) return;
    var dx = e.changedTouches[0].clientX - touchStartX;
    if (Math.abs(dx) > 40) { dx < 0 ? next() : prev(); restartAutoplay(); }
    touchStartX = null;
  });

  render();
  startAutoplay();
}
