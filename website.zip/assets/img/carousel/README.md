# Carousel photos

Drop images into this folder using these exact filenames: the home page
(`index.html`) already references them, so once a file exists here it
replaces the dashed placeholder box automatically (nothing else to edit).

| Filename     | What it should show                                              |
|--------------|--------------------------------------------------------------------|
| `slide-1.jpg`| CAD assembly render: full mechanism, RUD cable loop + FE direct-drive link |
| `slide-2.jpg`| Electronics / PCB: power, servo bus, signal-conditioning hardware |
| `slide-3.jpg`| sEMG sensor placement on the forearm                                |
| `slide-4.jpg`| Bench test on the surrogate identification rig (known J, B, K)     |
| `slide-5.jpg`| Team working session                                                |

**Recommended:** landscape orientation, roughly 1600&times;700px (a 16:7
ratio, matching the carousel's aspect ratio) so photos fill the frame
without heavy cropping. JPG or PNG both work, just keep the filenames
above (or update the `src` in `index.html` if you rename them).

Want more or fewer slides? Copy or delete a `<div class="carousel-slide">`
block in `index.html`'s Project Gallery section; the JavaScript reads
however many slides are present, no other changes needed.
