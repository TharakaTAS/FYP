# Signal Processing page photos

Drop your own project images into this folder using these exact filenames;
`signal-processing.html` already references them and will swap out the
dashed placeholder box automatically once each file exists.

| Filename                    | What goes here                                              |
|-------------------------------|--------------------------------------------------------------|
| `simulink-overview.jpg`     | Screenshot of the full Simulink preprocessing model           |
| `simulink-subsystem.jpg`    | Close-up screenshot of the filtering subsystem                |
| `result-raw.jpg`            | Plot of a raw, unprocessed EMG recording                      |
| `result-clean.jpg`          | Plot of the same recording after the pipeline runs on it      |

**Recommended:** landscape, roughly 4:3, at least 800px wide. These four
slots are meant for your own real work (not stock photos), so use actual
screenshots and plots from your Simulink model and MATLAB output.
