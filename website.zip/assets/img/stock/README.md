# Credited stock photos

Illustrative (non-project) photos used across the site. All are free-to-use
Pexels photos, credited with a hyperlink in the page itself (see the
`<figcaption>` under each image).

**About page** (`about.html`): a clinical arm assessment next to "Why This
Matters", and a human/robotic hand image in the page's hero.

**Signal Processing page** (`signal-processing.html`): an electrode/skin
contact photo next to "Acquiring the Signal", an oscilloscope waveform photo
next to "Why Preprocessing Matters", and a data-analysis photo next to
"MATLAB & the Signal Processing Toolbox".

This environment's network access couldn't download the files directly, so
right now all images are hot-linked straight from Pexels' own CDN
(`images.pexels.com`), that's within the Pexels License (free for
commercial and non-commercial use, no attribution required, though it's
still given here) and works fine on the live site. The only downside is that
the site depends on Pexels staying up and keeping those URLs valid.

If you'd rather self-host them (recommended before the final submission, so
the site has zero external dependencies), download the files below into this
folder using these exact names, then swap each
`<img src="https://images.pexels.com/...">` for the matching local path
(e.g. `assets/img/stock/clinical-assessment.jpg`):

| Filename                  | Source                                                                                                      | Photographer      |
|----------------------------|--------------------------------------------------------------------------------------------------------------|--------------------|
| `clinical-assessment.jpg` | https://www.pexels.com/photo/crop-orthopedist-examining-arm-of-faceless-female-patient-in-clinic-4506074/    | Karola G           |
| `human-robot-hand.jpg`    | https://www.pexels.com/photo/hand-with-silver-glove-holding-a-robot-hand-8849283/                             | Tara Winstead      |
| `electrode-skin.jpg`      | https://www.pexels.com/photo/physiotherapy-session-with-electrotherapy-pads-30483032/                         | Cansu Hangül       |
| `oscilloscope-wave.jpg`   | https://www.pexels.com/photo/close-up-shot-of-a-oscillograph-7858253/                                         | cottonbro studio   |
| `data-analysis.jpg`       | https://www.pexels.com/photo/graph-on-laptop-screen-3912976/                                                  | ThisIsEngineering  |

Keep the credit line in each page's `<figcaption>` either way, it's good
practice even though the Pexels License doesn't require it.
