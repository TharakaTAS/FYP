# Team photos

Drop headshots into this folder using these exact filenames: the home
page already references them and will swap out the placeholder circle
automatically.

| Filename          | Person                   |
|-------------------|---------------------------|
| `tharaka.jpg`     | T. A. S. Tharaka          |
| `ariyarathna.jpg` | A. G. T. Ariyarathna      |
| `weerakkody.jpg`  | W. A. S. S. Weerakkody    |

**Recommended:** square, at least 400&times;400px, headshot cropped
close (the circle crop will cut off anything near the edges).
