#!/usr/bin/env python3
"""One-off generator for the placeholder nav pages. Not part of the site
runtime; the site itself is plain static HTML/CSS/JS with no build step.
This script just avoids hand-duplicating the header/footer six times."""

import pathlib

ROOT = pathlib.Path(__file__).parent.parent

NAV_ITEMS = [
    ("index.html", "Home"),
    ("about.html", "About"),
    ("signal-processing.html", "Signal Processing"),
    ("mechanical-design.html", "Mechanical Design"),
    ("control-design.html", "Control Design"),
    ("ml-design.html", "Machine Learning"),
    ("future-work.html", "Future Work"),
    ("faq.html", "FAQ"),
]

FOOTER = """
<footer class="site-footer">
  <div class="container footer-inner">

    <div class="footer-col">
      <h4>MC04 &middot; Wrist Exoskeleton</h4>
      <p>
        Final Year Project, MC 4206<br>
        General Sir John Kotelawala Defence University, Rathmalana, Sri Lanka
      </p>
    </div>

    <div class="footer-col">
      <h4>Contact</h4>
      <div class="footer-contact-line">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 6l-10 7L2 6"/><rect x="2" y="4" width="20" height="16" rx="2"/></svg>
        <a href="mailto:tastharaka@gmail.com">tastharaka@gmail.com</a>
      </div>
      <div class="footer-contact-line">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.362 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.338 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
        <a href="tel:+94704997962">070 499 7962</a>
      </div>
    </div>

    <div class="footer-col">
      <h4>Connect</h4>
      <div class="footer-social">
        <a href="[PLACEHOLDER: LinkedIn URL]" aria-label="LinkedIn">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.04-1.85-3.04-1.86 0-2.14 1.45-2.14 2.94v5.67H9.34V9h3.41v1.56h.05c.48-.9 1.64-1.85 3.38-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.07 2.07 0 1 1 0-4.13 2.07 2.07 0 0 1 0 4.13zM7.12 20.45H3.56V9h3.56v11.45z"/></svg>
        </a>
        <a href="[PLACEHOLDER: GitHub URL]" aria-label="GitHub">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 .5C5.73.5.5 5.73.5 12c0 5.1 3.3 9.42 7.88 10.95.58.1.79-.25.79-.56v-2.17c-3.2.7-3.88-1.36-3.88-1.36-.53-1.34-1.29-1.7-1.29-1.7-1.05-.72.08-.7.08-.7 1.16.08 1.78 1.2 1.78 1.2 1.03 1.78 2.71 1.26 3.37.96.1-.75.4-1.26.73-1.55-2.55-.29-5.24-1.28-5.24-5.68 0-1.26.45-2.28 1.19-3.09-.12-.29-.52-1.46.11-3.05 0 0 .97-.31 3.18 1.18a11.1 11.1 0 0 1 5.79 0c2.2-1.49 3.17-1.18 3.17-1.18.64 1.59.24 2.76.12 3.05.74.81 1.19 1.83 1.19 3.09 0 4.41-2.7 5.39-5.27 5.67.42.36.78 1.07.78 2.16v3.2c0 .31.21.67.8.56A10.52 10.52 0 0 0 23.5 12C23.5 5.73 18.27.5 12 .5z"/></svg>
        </a>
      </div>
    </div>

  </div>
  <div class="footer-bottom">
    <p>&copy; <span id="year"></span> T. A. S. Tharaka. Built and maintained as part of MC 4206.</p>
  </div>
</footer>
"""


def header(active_file):
    links = []
    for href, label in NAV_ITEMS:
        cls = ' class="active" aria-current="page"' if href == active_file else ''
        links.append(f'<li><a href="{href}"{cls}>{label}</a></li>')
    links_html = "\n        ".join(links)
    return f"""
<header class="site-header">
  <div class="container header-inner">
    <a href="index.html" class="brand">
      <span class="brand-mark">MC04</span>
      <span class="brand-text">Wrist Exoskeleton<br><small>FYP MC 4206 &middot; Team MC 04</small></span>
    </a>
    <button class="nav-toggle" id="navToggle" aria-label="Toggle navigation" aria-expanded="false" aria-controls="siteNav">
      <span></span><span></span><span></span>
    </button>
    <nav class="site-nav" id="siteNav">
      <ul>
        {links_html}
      </ul>
    </nav>
  </div>
</header>
"""


def page(filename, title, badge, heading, body_html):
    active = filename
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title} | MC04 &middot; Wrist Exoskeleton</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>
{header(active)}
<main id="main">
  <section class="placeholder-page">
    <div class="container">
      <span class="placeholder-badge">{badge}</span>
      <h1>{heading}</h1>
      {body_html}
    </div>
  </section>
</main>
{FOOTER}
<script src="js/script.js"></script>
</body>
</html>
"""
    (ROOT / filename).write_text(html, encoding="utf-8")
    print("wrote", filename)


## about.html and signal-processing.html are hand-authored (not stubs); see
## those files directly. Both reuse the same header()/FOOTER markup this
## script generates for the others, copied in by hand, so keep them in sync
## if the shared header/footer changes.

page(
    "mechanical-design.html",
    "Mechanical Design",
    "Page in progress",
    "Mechanical Design",
    """
    <p>
      Covers the kinematic architecture, the two-axis transmission (RUD driven through a
      cable loop, FE direct-driven), the forearm cuff, hard-stop safety case, and mass
      and materials budget.
    </p>
    <p>[PLACEHOLDER: mechanical drawings, CAD renders, and the design-decision narrative for this subsystem]</p>
    """,
)

page(
    "control-design.html",
    "Control Design",
    "Page in progress",
    "Control Design",
    """
    <p>
      Covers the admittance control architecture, the plant and target-impedance models,
      the derived stability rules, the transmission-compliance torque estimate (SEA on
      RUD; bus-reported load on FE), and the assist-as-needed scheme.
    </p>
    <p>[PLACEHOLDER: full derivation, block diagrams, and simulation/validation results for this subsystem]</p>
    """,
)

page(
    "ml-design.html",
    "Machine Learning",
    "Page in progress",
    "Machine Learning",
    """
    <p>
      Covers sEMG intent estimation: autoencoder reconstruction of paretic-side signal
      from the unaffected side, classification of motion class, and RMS-based magnitude
      estimation, benchmarked against a classical proportional-myoelectric baseline
      rather than assumed superior to it.
    </p>
    <p>[PLACEHOLDER: architecture diagram, training details, and benchmark results]</p>
    """,
)

page(
    "future-work.html",
    "Future Work",
    "Page in progress",
    "Future Work",
    """
    <p>
      Work staged beyond this review's deliverable: benchmarking the ML classifier
      against the classical baseline and a closed-loop hardware demonstration with
      measured stability margins (near-term), through to MIMO decoupling of the coupled
      stiffness axes, patient validation under a separate ethics application, and a
      wearable, ADL-capable device (longer-term).
    </p>
    <p>[PLACEHOLDER: full tiered backlog with effort estimates]</p>
    """,
)

page(
    "faq.html",
    "FAQ",
    "Page in progress",
    "Frequently Asked Questions",
    """
    <p>[PLACEHOLDER: questions the panel or readers have actually asked, answered plainly,
    e.g. why admittance over impedance control, why measurement is the primary objective,
    what's validated on hardware today versus simulated.]</p>
    """,
)

print("done")
